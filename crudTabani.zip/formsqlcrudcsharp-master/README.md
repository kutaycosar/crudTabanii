# formsqlcrudcsharp
c sharp basic crud functions
